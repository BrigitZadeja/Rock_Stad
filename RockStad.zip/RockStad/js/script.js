$(document).ready(function(){
  var hasBeenClicked = true;

  //if hover, image background and text will be changed
  $("#tc1").hover(function(){
      if (hasBeenClicked) {
          // The step has been selected.
          $(".bkg-mountain").removeClass("tc1 tc2 tc3 tc4");
          $(".bkg-mountain").addClass("tc1");
          $(".bkg-mountain h1").text("La nascita di Rockstad");
          $(".bkg-mountain h2").text("La nostra città incastonata nella roccia nasce molto tempo fa...");
          $(".bkg-mountain p").text("Rockstad nasce durante il Rinascimento. Il territorio roccioso era di proprità di una nobiliare famiglia italiana.");
          //The mouseover
          $('#tc1').addClass("tc1-width");
          hasBeenClicked=false;
      } else {
          // The step has not been selected.
          $(".bkg-mountain").removeClass("tc1 tc2 tc3 tc4");
          $(".bkg-mountain h1").text("La storia di Rockstad");
          $(".bkg-mountain h2").text("Sei curioso? Percorri la storia della città cliccando sui cerchi");
          $(".bkg-mountain p").text("Rock Stad vanta una storia unica e incredibile. Nasce dalla volontà di Piero e Silvana, due amanti della montagna.");
          $('#tc1').removeClass("tc1-width");
          hasBeenClicked=true;
      }
  });

  $("#tc2").hover(function(){
      if (hasBeenClicked) {
          // The step has been selected.
          $(".bkg-mountain").removeClass("tc1 tc2 tc3 tc4");
          $(".bkg-mountain").addClass("tc2");
          $(".bkg-mountain h1").text("La scomparsa di Rockstad...");
          $(".bkg-mountain h2").text("Dopo uno sviluppo inziale la città viene abbandonata e dimenticata...");
          $(".bkg-mountain p").text("Durante i suoi primi anni Rockstad era meta di molti viaggi commerciali. La roccia si sgretola e porta gli abitanti ad abbandonare la città.");
          //The mouseover
          $('#tc2').addClass("tc2-width");
          hasBeenClicked=false;
      } else {
          // The step has not been selected.
          $(".bkg-mountain").removeClass("tc1 tc2 tc3 tc4");
          $(".bkg-mountain h1").text("La storia di Rockstad");
          $(".bkg-mountain h2").text("Sei curioso? Percorri la storia della città cliccando sui cerchi");
          $(".bkg-mountain p").text("Rock Stad vanta una storia unica e incredibile. Nasce dalla volontà di Piero e Silvana, due amanti della montagna.");
          $('#tc2').removeClass("tc2-width");
          hasBeenClicked=true;
      }
  });

  $("#tc3").hover(function(){
      if (hasBeenClicked) {
          // The step has been selected.
          $(".bkg-mountain").removeClass("tc1 tc2 tc3 tc4");
          $(".bkg-mountain").addClass("tc3");
          $(".bkg-mountain h1").text("La rinascita di Rockstad");
          $(".bkg-mountain h2").text("La città viene riscoperta, rinnovata completamente e vive una seconda vita...");
          $(".bkg-mountain p").text("Siamo nel 1970 e Piero e Silvana scoprono i resti di Rockstad. Si innamorano di quel luogo magico e incantato: Rockstad rinasce.");
          //The mouseover
          $('#tc3').addClass("tc3-width");
          hasBeenClicked=false;
      } else {
          // The step has not been selected.
          $(".bkg-mountain").removeClass("tc1 tc2 tc3 tc4");
          $(".bkg-mountain h1").text("La storia di Rockstad");
          $(".bkg-mountain h2").text("Sei curioso? Percorri la storia della città cliccando sui cerchi");
          $(".bkg-mountain p").text("Rock Stad vanta una storia unica e incredibile. Nasce dalla volontà di Piero e Silvana, due amanti della montagna.");
          $('#tc3').removeClass("tc3-width");
          hasBeenClicked=true;
      }
  });

  $("#tc4").hover(function(){
      if (hasBeenClicked) {
          // The step has been selected.
          $(".bkg-mountain").removeClass("tc1 tc2 tc3 tc4");
          $(".bkg-mountain").addClass("tc4");
          $(".bkg-mountain h1").text("La popolarità di Rockstad");
          $(".bkg-mountain h2").text("La città rinasce grazie a Silvana e Piero che creano attrazioni uniche...");
          $(".bkg-mountain p").text("La città diventa famosa e si popola di turisti grazie alle esperienze indicmenticabili che si possono fare sul territorio.");
          //The mouseover
          $('#tc4').addClass("tc4-width");
          hasBeenClicked=false;
      } else {
          // The step has not been selected.
          $(".bkg-mountain").removeClass("tc1 tc2 tc3 tc4");
          $(".bkg-mountain h1").text("La storia di Rockstad");
          $(".bkg-mountain h2").text("Sei curioso? Percorri la storia della città cliccando sui cerchi");
          $(".bkg-mountain p").text("Rock Stad vanta una storia unica e incredibile. Nasce dalla volontà di Piero e Silvana, due amanti della montagna.");
          $('#tc4').removeClass("tc4-width");
          hasBeenClicked=true;
      }
  });




});